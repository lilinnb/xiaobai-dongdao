plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xiaobai.dongdao"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xiaobai.dongdao"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}
