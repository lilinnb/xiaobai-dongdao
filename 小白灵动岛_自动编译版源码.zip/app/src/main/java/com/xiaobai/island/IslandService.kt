package com.xiaobai.island
import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.math.abs

class IslandService : Service() {
 private lateinit var wm:WindowManager
 private var island:LinearLayout?=null
 private lateinit var lp:WindowManager.LayoutParams
 private var expanded=false
 override fun onCreate(){ super.onCreate(); notification(); wm=getSystemService(WINDOW_SERVICE) as WindowManager; createIsland() }
 private fun notification(){
  val id="xiaobai_island"
  if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(id,"小白灵动岛",NotificationManager.IMPORTANCE_LOW))
  val n=Notification.Builder(this,id).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("小白灵动岛正在运行").setContentText("返回应用可关闭悬浮窗").build()
  startForeground(7,n)
 }
 private fun pillBg()=GradientDrawable().apply{setColor(Color.rgb(10,11,14));cornerRadius=48f;setStroke(1,Color.DKGRAY)}
 private fun text(s:String,size:Float)=TextView(this).apply{ text=s;textSize=size;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(16,10,16,10) }
 private fun createIsland(){
  val v=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER;background=pillBg();addView(text("小白灵动岛   ⌄",14f))}
  island=v
  lp=WindowManager.LayoutParams(190.dp(),48.dp(),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL;y=8.dp()}
  v.setOnTouchListener(object:View.OnTouchListener{
   var x=0f;var y=0f;var sx=0;var sy=0;var moved=false
   override fun onTouch(view:View,e:MotionEvent):Boolean{when(e.action){
    MotionEvent.ACTION_DOWN->{x=e.rawX;y=e.rawY;sx=lp.x;sy=lp.y;moved=false;return true}
    MotionEvent.ACTION_MOVE->{val dx=(e.rawX-x).toInt();val dy=(e.rawY-y).toInt();if(abs(dx)+abs(dy)>8.dp())moved=true;lp.x=sx+dx;lp.y=(sy+dy).coerceAtLeast(0);wm.updateViewLayout(v,lp);return true}
    MotionEvent.ACTION_UP->{if(!moved)toggle();return true}
   };return false}
  })
  wm.addView(v,lp)
 }
 private fun toggle(){
  val v=island?:return;v.removeAllViews()
  if(!expanded){
   v.addView(text("小白工具箱   ⌃",15f))
   listOf("灵敏度记录","配置管理","训练计时","画质设置").forEach{ item->v.addView(text(item,13f).apply{setOnClickListener{Toast.makeText(this@IslandService,"$item：功能原型",Toast.LENGTH_SHORT).show()}})}
   v.addView(text("点此收起",11f).apply{setOnClickListener{toggle()}})
   lp.width=240.dp();lp.height=WindowManager.LayoutParams.WRAP_CONTENT
  }else{v.addView(text("小白灵动岛   ⌄",14f));lp.width=190.dp();lp.height=48.dp()}
  expanded=!expanded;wm.updateViewLayout(v,lp)
 }
 private fun Int.dp()=(this*resources.displayMetrics.density).toInt()
 override fun onDestroy(){island?.let{try{wm.removeView(it)}catch(_:Exception){}};island=null;stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}