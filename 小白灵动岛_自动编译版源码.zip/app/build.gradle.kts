plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.xiaobai.island"; compileSdk = 35
 defaultConfig { applicationId = "com.xiaobai.island"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" } }
