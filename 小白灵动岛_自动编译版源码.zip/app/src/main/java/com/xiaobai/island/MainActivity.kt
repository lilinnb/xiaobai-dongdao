package com.xiaobai.island
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val box=LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(30,40,30,40); setBackgroundColor(Color.rgb(15,18,25)) }
  box.addView(TextView(this).apply { text="小白灵动岛"; textSize=28f; setTextColor(Color.WHITE); gravity=Gravity.CENTER })
  box.addView(TextView(this).apply { text="独立悬浮工具面板 · 无需 Root\n不读取或修改游戏进程与文件"; textSize=15f; setTextColor(Color.LTGRAY); gravity=Gravity.CENTER; setPadding(0,20,0,24) })
  box.addView(Button(this).apply { text="① 授予悬浮窗权限"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
  box.addView(Button(this).apply { text="② 启动灵动岛"; setOnClickListener { if(Settings.canDrawOverlays(this@MainActivity)) startForegroundService(Intent(this@MainActivity,IslandService::class.java)) else Toast.makeText(this@MainActivity,"请先授予悬浮窗权限",Toast.LENGTH_LONG).show() } })
  box.addView(Button(this).apply { text="关闭灵动岛"; setOnClickListener { stopService(Intent(this@MainActivity,IslandService::class.java)) } })
  setContentView(box)
 }
}