package com.xiaobai.dongdao

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }

        val title = TextView(this).apply {
            text = "小白灵动岛"
            textSize = 26f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val island = TextView(this).apply {
            text = "●  小白灵动岛\n点击展开"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(25, 25, 25))
            setPadding(32, 22, 32, 22)
        }
        val islandParams = LinearLayout.LayoutParams(-1, -2)
        islandParams.setMargins(0, 36, 0, 24)
        root.addView(island, islandParams)

        var expanded = false
        island.setOnClickListener {
            expanded = !expanded
            island.text = if (expanded) {
                "●  小白灵动岛\n已展开 · 点击收起"
            } else {
                "●  小白灵动岛\n点击展开"
            }
        }

        val permissionButton = Button(this).apply {
            text = "检查悬浮窗权限"
            setOnClickListener {
                Toast.makeText(
                    this@MainActivity,
                    "当前版本先提供应用内灵动岛演示；悬浮窗功能尚未启用。",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        root.addView(permissionButton, LinearLayout.LayoutParams(-1, -2))

        val note = TextView(this).apply {
            text = "提示：这是可编译的基础演示版。点击黑色胶囊可展开或收起。"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(note, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }
}
